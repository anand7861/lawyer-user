<div> <a href="logout.php"><input type='button' value='Logout'></a><hr></div>

 <?php
            
             include("../include/config.php");
			 $id=$_GET["n"];
			 $cmd="select name from user where userid='$id'";
			$rst=mysql_query($cmd);
			$row=mysql_fetch_array($rst);
			echo "welcome ". $row[0]."<hr>";
			
			 $cmd2="select * from notify where uid='$id' and status<>2";
			$rst2=mysql_query($cmd2);
			while($row2=mysql_fetch_array($rst2))
			{
				$cmd3="select name from lawyer where lawid='$row2[2]'";
			$rst3=mysql_query($cmd3);
			$row3=mysql_fetch_array($rst3);
			if($row2[3]==0)
				 echo $row3[0]."has decline your booking";
			 else if($row2[3]==1)
				 echo $row3[0]."has accept your booking";
			 
			 echo "<form method='post' action='../redirect.php'><input type=hidden value=$id name='uid'><input type=hidden value=$row2[2] name='lawyerid'><input type='submit' value='Ok' ></a></p></form><br>";
        
			}
           
           
			echo "<hr>";
				
			$cmd1="select * from lawyer";

            $rst1=mysql_query($cmd1);
            while($row1=mysql_fetch_array($rst1))
			{
				$cmd4="select * from book where lid='$row1[0]' and uid='$id'";
			   $rst4=mysql_query($cmd4);
			   $row4=mysql_fetch_array($rst4);
			    $t=$row4[3];
			   if($row4!=0)
			   {
				   while($row4=mysql_fetch_array($rst4))
				   { $t=$row4[3];}
			   if($t==0 || $t==1)
			   {
				echo $row1[2]."<br>";
				echo "<input type='button' value='Booked' ><br><br><br>";
			   }
			   else
			   {
				   echo $row1[2]."<br>";
				echo "<form method='post' action='../booktime.php'><input type=hidden value=$id name='uid'><input type=hidden value=$row1[0] name='lawyerid'><input type='submit' value='Book' ></a></p></form><br>";
			   
			   }
			   }
			   else
			   {
				   echo $row1[2]."<br>";
				echo "<form method='post' action='../booktime.php'><input type=hidden value=$id name='uid'><input type=hidden value=$row1[0] name='lawyerid'><input type='submit' value='Book' ></a></p></form><br>";
			   
			   }
				   
			}
?>

