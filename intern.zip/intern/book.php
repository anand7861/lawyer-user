
<?php
            
             include("include/config.php");
			 $uid=$_POST["uid"];
             $lid=$_POST["lawyerid"];
			 $date=$_POST["date"];
			 $time=$_POST["time"];
             $cmd2="insert into book(uid,lid,status,time,date) values('$uid','$lid',0,'$time','$date')";
             if($rst2=mysql_query($cmd2))
				 {
				 echo "your booking request has been sent to your lawyer.Thank you";
			 echo "<form method='post' action='userpages1/home.php?n=$uid'><input type=hidden value=$id name='uid'><input type=hidden value=$row2[2] name='lawyerid'><input type='submit' value='Ok' ></a></p></form><br>";
				 }
			 else
				 echo "error"
			
			?>