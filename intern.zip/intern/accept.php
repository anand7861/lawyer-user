<?php
            
             include("include/config.php");
			 $uid=$_POST["uid"];
             $lid=$_POST["lawyerid"];
             $cmd2="insert into notify(uid,lid,status) values('$uid','$lid',1)";
             if($rst2=mysql_query($cmd2))
				 echo "your accept the client offer";
			 else
				 echo "error";
			 $cmd3="update book set status=1 where uid='$uid' and lid='$lid'";
            if($rst3=mysql_query($cmd3))
				echo "<form method='post' action='userpages2/home.php?n=$lid'><input type=hidden value=$id name='uid'><input type=hidden value=$row2[2] name='lawyerid'><input type='submit' value='Ok' ></a></p></form><br>";
        
			
			?>