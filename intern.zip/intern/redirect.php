<?php 
 include("include/config.php");
			 $uid=$_POST["uid"];
             $lid=$_POST["lawyerid"];
 $cmd3="update notify set status=2 where uid='$uid' and lid='$lid'";
            if($rst3=mysql_query($cmd3))
				header("Location:userpages1/home.php?n=$uid");
				
?>