<?php 
session_start();

?>
<html>
<head>
<title> Suits.com </title>
<link href="style.css" rel=stylesheet>

<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href='http://fonts.googleapis.com/css?family=Rokkitt' rel='stylesheet' type='text/css'>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 

</head>
<body>
<center>
<div id=header> Suits</div>
<div><a href="index.php"><font color="red">login as User</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</font><a href="lawyersignin.php">login as lawyer</a></div>
 <div> loging in as User</div>
 <form method="POST" action="checkusersignin.php">
<table id=form1>
<tr><td><input type="text" name="userid" placeholder="ENTER USER ID" Required> </td></tr>
<tr><td><input type="password" name="userpassword" placeholder="ENTER USER PASSWORD" Required> </td></tr>
<tr><td><input type="submit"  value="Login"> </td></tr>
<?php 
if(isset($_GET["status"]))
	echo "<tr><td> <font color=red size=3> Invalid Id or Password <a href=signup.php> Do Sign Up </a> </font</td></tr>";
?>



</table>
</form>