<?php 
session_start();

include("include/config.php");
$userid=$_POST["lawyerid"];
$userpassword=$_POST["userpassword"];
$cmd="select * from lawyer where lawid='$userid' and pass='$userpassword'";
$rst=mysql_query($cmd);
$row=mysql_fetch_array($rst);
if($row==0)
{
	header("Location:lawyersignin.php?status=invalid");
	
}
else
{
	
	$_SESSION["userid"]=$_POST["lawyerid"];
     
	header("Location:userpages2/home.php?n=$_SESSION[userid]");
	
}
?>





