<?php
            
             include("../include/config.php");
			 $lid=$_GET["n"];
             
echo "provide availability<hr><br><form method='post' action=update.php>time :<br>from<input type='time' name=from REQUIRED>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp to<input type='time' name=to REQUIRED><br><br>date : <input type='date' name=date REQUIRED><input type=hidden value=$lid name='lawyerid'><br><input type='submit' value='confirm' ></form>";
?>