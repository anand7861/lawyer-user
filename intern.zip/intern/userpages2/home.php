
<div> <a href="logout.php"><input type='button' value='Logout'></a><hr>
<?php
            
             include("../include/config.php");
			 $id=$_GET["n"];
             $cmd2="select name from lawyer where lawid='$id'";
			$rst2=mysql_query($cmd2);
			$row2=mysql_fetch_array($rst2);
			echo "welcome ". $row2[0]."<br>";
		
			echo "<a href='availability.php?n=$id'><input type='button' value='set availability'></a></div><hr>";
			$cmd="select * from book where lid='$id'";
			$rst=mysql_query($cmd);
			while($row=mysql_fetch_array($rst))
			{
				if($row[3]==0)
				{
				$cmd1="select name from user where userid='$row[1]'";
			$rst1=mysql_query($cmd1);
			$row1=mysql_fetch_array($rst1);
			echo $row1[0]." has booked you.<br>";
			echo "<form method='post' action='../accept.php'><input type=hidden value=$row[1] name='uid'><input type=hidden value=$id name='lawyerid'><input type='submit' value='Accept' ></form>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<form method='post' action='../decline.php' style='float:left'><input type=hidden value=$row[1] name='uid'><input type=hidden value=$id name='lawyerid'><input type='submit' value='Decline' ></form><br><br><hr>";
				}
			}
?>

<div>