<?php
            
             include("../include/config.php");
			 $from=$_POST["from"];
			 $to=$_POST["to"];
			 $date=$_POST["date"];
             $lid=$_POST["lawyerid"];
             
			 
			$cmd3="update  lawyer set fromt='$from' ,tot='$to',date='$date' where lawid='$lid'";
            if($rst3=mysql_query($cmd3))
				echo "you have updated your Availability successfully<br><a href='home.php?n=$lid'><input type='button' value='ok'></a>";
				
             else
				  echo "error";
				?>