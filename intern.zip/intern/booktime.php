<?php
            
             include("include/config.php");
			 $uid=$_POST["uid"];
             $lid=$_POST["lawyerid"];
echo "book your slot<br><form method='post' action=book.php>time<input type='time' name=time REQUIRED>date<input type='date' name=date REQUIRED><input type=hidden value=$lid name='lawyerid'><input type=hidden value=$uid name='uid'><br><input type='submit' value='confirm' ></form>";

?>
