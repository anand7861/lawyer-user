<?php
error_reporting(0);
$con=mysql_connect("localhost","root","");
$db=mysql_select_db("intern");
?>