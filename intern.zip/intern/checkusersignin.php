<?php 
session_start();


include("include/config.php");
$userid=$_POST["userid"];
$userpassword=$_POST["userpassword"];
$cmd="select * from user where userid='$userid' and pass='$userpassword'";
$rst=mysql_query($cmd);
$row=mysql_fetch_array($rst);
if($row==0)
{
	header("Location:index.php?status=invalid");
	
}
else
{
	
	$_SESSION["userid"]=$_POST["userid"];
	
	header("Location:userpages1/home.php?n=$_SESSION[userid]");
	
}
?>





